from django.db import models
from django.contrib.auth.models import User

class VoterProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    voter_id = models.CharField(max_length=20, unique=True)
    is_approved = models.BooleanField(default=False)
    has_voted = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.user.username} ({self.voter_id})"

class Candidate(models.Model):
    name = models.CharField(max_length=100)
    party = models.CharField(max_length=100)
    symbol = models.ImageField(upload_to='candidates/', blank=True, null=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} - {self.party}"

class Vote(models.Model):
    voter = models.ForeignKey(User, on_delete=models.CASCADE)
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Vote by {self.voter.username} for {self.candidate.name}"
