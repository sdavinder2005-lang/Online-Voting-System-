from django import forms
from django.contrib.auth.models import User
from .models import VoterProfile, Candidate

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)
    voter_id = forms.CharField(max_length=20, help_text="Enter unique Voter ID")

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password != confirm_password:
            raise forms.ValidationError("Passwords do not match")
        
        voter_id = cleaned_data.get("voter_id")
        if VoterProfile.objects.filter(voter_id=voter_id).exists():
             self.add_error('voter_id', "Voter ID already registered.")
        return cleaned_data

class CandidateForm(forms.ModelForm):
    class Meta:
        model = Candidate
        fields = ['name', 'party', 'symbol', 'description']
