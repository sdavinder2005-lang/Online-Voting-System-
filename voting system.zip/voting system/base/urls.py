from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_user, name='register'),
    path('login/', views.login_user, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('dashboard/', views.voter_dashboard, name='voter_dashboard'),
    path('vote/<int:candidate_id>/', views.vote, name='vote'),
    path('confirmation/', views.confirmation, name='confirmation'),
    
    # Admin
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/approve/<int:voter_id>/', views.approve_voter, name='approve_voter'),
    path('admin/create_candidate/', views.create_candidate, name='create_candidate'),
    path('admin/delete_candidate/<int:candidate_id>/', views.delete_candidate, name='delete_candidate'),
]
