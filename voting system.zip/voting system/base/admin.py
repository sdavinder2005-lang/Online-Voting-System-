from django.contrib import admin
from .models import VoterProfile, Candidate, Vote

@admin.register(VoterProfile)
class VoterProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'voter_id', 'is_approved', 'has_voted')
    list_filter = ('is_approved', 'has_voted')
    search_fields = ('user__username', 'voter_id')
    actions = ['approve_voters']

    @admin.action(description='Approve selected voters')
    def approve_voters(self, request, queryset):
        queryset.update(is_approved=True)

@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    list_display = ('name', 'party')
    search_fields = ('name', 'party')

@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('voter', 'candidate', 'timestamp')
    list_filter = ('candidate', 'timestamp')
