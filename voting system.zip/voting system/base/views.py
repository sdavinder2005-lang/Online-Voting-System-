from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, CandidateForm
from .models import VoterProfile, Candidate, Vote
from django.db.models import Count

def home(request):
    return render(request, 'base/home.html')

def register_user(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            # Create VoterProfile
            VoterProfile.objects.create(user=user, voter_id=form.cleaned_data['voter_id'])
            messages.success(request, "Registration successful! Please wait for admin approval.")
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'base/register_fixed.html', {'form': form})

def login_user(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_superuser:
                login(request, user)
                return redirect('admin_dashboard')
            
            try:
                profile = user.voterprofile
                if profile.is_approved:
                    login(request, user)
                    return redirect('voter_dashboard')
                else:
                    messages.error(request, "Your account is not approved yet.")
            except VoterProfile.DoesNotExist:
                 messages.error(request, "Voter profile not found.")
        else:
             messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'base/login.html', {'form': form})

@login_required
def logout_user(request):
    logout(request)
    return redirect('home')

@login_required
def voter_dashboard(request):
    if request.user.is_superuser:
        return redirect('admin_dashboard')
    
    try:
        profile = request.user.voterprofile
    except VoterProfile.DoesNotExist:
        return redirect('home') # Should not happen if logged in properly

    candidates = Candidate.objects.all()
    context = {'candidates': candidates, 'profile': profile}
    return render(request, 'base/voter_dashboard.html', context)

@login_required
def vote(request, candidate_id):
    if request.user.is_superuser:
        messages.warning(request, "Admins cannot vote.")
        return redirect('admin_dashboard')

    profile = request.user.voterprofile
    if profile.has_voted:
        messages.warning(request, "You have already voted.")
        return redirect('voter_dashboard')

    candidate = get_object_or_404(Candidate, id=candidate_id)
    
    # Create Vote
    Vote.objects.create(voter=request.user, candidate=candidate)
    
    # Update Profile
    profile.has_voted = True
    profile.save()
    
    return redirect('confirmation')

@login_required
def confirmation(request):
    return render(request, 'base/confirmation.html')

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('voter_dashboard')
    
    # Get stats
    candidates = Candidate.objects.all() # Or use aggregation for vote counts
    # We can calculate votes here
    candidate_data = []
    for cand in candidates:
        count = Vote.objects.filter(candidate=cand).count()
        candidate_data.append({'candidate': cand, 'count': count})
        
    unapproved_voters = VoterProfile.objects.filter(is_approved=False)
    
    context = {
        'candidate_data': candidate_data,
        'unapproved_voters': unapproved_voters
    }
    return render(request, 'base/admin_dashboard.html', context)

@login_required
def approve_voter(request, voter_id):
    if not request.user.is_superuser:
        return redirect('home')
    
    voter = get_object_or_404(VoterProfile, id=voter_id)
    voter.is_approved = True
    voter.save()
    messages.success(request, f"Voter {voter.user.username} approved.")
    return redirect('admin_dashboard')

@login_required
def delete_candidate(request, candidate_id):
    if not request.user.is_superuser:
         return redirect('home')
    candidate = get_object_or_404(Candidate, id=candidate_id)
    candidate.delete()
    messages.success(request, "Candidate deleted.")
    return redirect('admin_dashboard')
    
@login_required
def create_candidate(request):
    if not request.user.is_superuser:
        return redirect('home')
        
    if request.method == 'POST':
        form = CandidateForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Candidate created successfully.")
            return redirect('admin_dashboard')
    else:
        form = CandidateForm()
    return render(request, 'base/create_candidate.html', {'form': form})
